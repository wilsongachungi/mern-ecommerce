 import {useEffect, useState} from "react";
 import {useDispatch, useSelector} from "react-redux";
 import {useNavigate} from "react-router-dom";
//  import {
//    saveshippingAddress, savePaymentMethod
//  } from "../../redux/features/cart/cartSlice"

const Shipping = () => {
 return (
    <div>Shipping</div>
 )
}

export default Shipping